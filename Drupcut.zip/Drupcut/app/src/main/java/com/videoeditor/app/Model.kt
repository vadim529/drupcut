@file:OptIn(UnstableApi::class)

package com.videoeditor.app

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi

const val IMAGE_DEFAULT_MS = 3_000L
const val IMAGE_MAX_MS = 10_000L
const val MIN_CLIP_MS = 300L

/** Один кліп на таймлайні. startMs..endMs — використана частина джерела. */
data class Clip(
    val id: Long,
    val uri: Uri,
    val isImage: Boolean,
    val sourceMs: Long,
    val startMs: Long,
    val endMs: Long,
) {
    val durationMs: Long get() = endMs - startMs

    fun toMediaItem(): MediaItem =
        if (isImage) {
            MediaItem.Builder().setUri(uri).setImageDurationMs(durationMs).build()
        } else {
            MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
                .build()
        }
}

enum class Ratio(val label: String, val w: Int, val h: Int) {
    R169("16:9", 1920, 1080),
    R916("9:16", 1080, 1920),
    R11("1:1", 1080, 1080),
}

sealed class ExportState {
    data object Idle : ExportState()
    data class Running(val progress: Int) : ExportState()
    data class Done(val uri: Uri) : ExportState()
    data class Error(val message: String) : ExportState()
}
