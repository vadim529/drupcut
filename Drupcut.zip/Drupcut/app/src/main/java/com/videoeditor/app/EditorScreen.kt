@file:OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)

package com.videoeditor.app

import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private fun fmt(ms: Long): String {
    val t = ms.coerceAtLeast(0)
    return "%02d:%02d.%d".format(t / 60000, (t / 1000) % 60, (t % 1000) / 100)
}

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val context = LocalContext.current
    val app = context.applicationContext
    val clips = vm.clips

    // ---------- Плеєр ----------
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var isPlaying by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var index by remember { mutableIntStateOf(0) }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }
    LaunchedEffect(player) {
        while (true) {
            posMs = player.currentPosition
            index = player.currentMediaItemIndex
            delay(100)
        }
    }
    // Синхронізація плейлиста з таймлайном
    LaunchedEffect(clips) {
        if (clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        val pending = vm.pendingSeekIndex
        vm.pendingSeekIndex = null
        val oldIndex = player.currentMediaItemIndex
        val i = (pending ?: oldIndex).coerceIn(0, clips.size - 1)
        val p = if (pending == null && i == oldIndex) player.currentPosition else 0L
        player.setMediaItems(clips.map { it.toMediaItem() }, i, p)
        player.prepare()
    }

    val current = clips.getOrNull(index)
    val before = clips.take(index).sumOf { it.durationMs }
    val total = clips.sumOf { it.durationMs }

    // ---------- Вибір медіа ----------
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) vm.addClips(app, uris)
    }
    val pickMedia = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {

        // Верхня панель
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Drupcut", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Button(onClick = { player.pause(); vm.export(app) }, enabled = clips.isNotEmpty()) {
                Text("Експорт")
            }
        }

        // Превʼю
        Box(
            Modifier.weight(1f).fillMaxWidth().background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (clips.isEmpty()) {
                TextButton(onClick = { pickMedia() }) { Text("＋ Додати відео або фото") }
            } else {
                AndroidView(
                    factory = { PlayerView(it).apply { this.player = player; useController = false } },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Час + плей
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalButton(
                onClick = { if (isPlaying) player.pause() else player.play() },
                enabled = clips.isNotEmpty()
            ) { Text(if (isPlaying) "⏸" else "▶") }
            Spacer(Modifier.width(12.dp))
            Text("${fmt(before + posMs)} / ${fmt(total)}", style = MaterialTheme.typography.bodyMedium)
        }

        // Інструменти
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val has = current != null
            TextButton(
                onClick = { player.pause(); vm.split(index, posMs) },
                enabled = has && current?.isImage == false
            ) { Text("✂ Розрізати") }
            TextButton(onClick = { vm.duplicate(index) }, enabled = has) { Text("⧉ Дублювати") }
            TextButton(onClick = { vm.move(index, -1) }, enabled = has && index > 0) { Text("◀ Лівіше") }
            TextButton(onClick = { vm.move(index, 1) }, enabled = has && index < clips.size - 1) { Text("Правіше ▶") }
            TextButton(onClick = { vm.delete(index) }, enabled = has) { Text("🗑 Видалити") }
        }

        // Обрізка вибраного кліпа
        if (current != null) {
            key(current.id, current.startMs, current.endMs) {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    if (current.isImage) {
                        var dur by remember { mutableFloatStateOf(current.endMs.toFloat()) }
                        Text("Тривалість фото: ${"%.1f".format(dur / 1000)} с", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = dur,
                            onValueChange = { dur = it },
                            onValueChangeFinished = { vm.setImageDuration(current.id, dur.toLong()) },
                            valueRange = 500f..IMAGE_MAX_MS.toFloat()
                        )
                    } else {
                        var range by remember { mutableStateOf(current.startMs.toFloat()..current.endMs.toFloat()) }
                        Text(
                            "Обрізка: ${fmt(range.start.toLong())} – ${fmt(range.endInclusive.toLong())}",
                            style = MaterialTheme.typography.labelMedium
                        )
                        RangeSlider(
                            value = range,
                            onValueChange = { range = it },
                            onValueChangeFinished = {
                                vm.trim(current.id, range.start.toLong(), range.endInclusive.toLong())
                            },
                            valueRange = 0f..current.sourceMs.toFloat()
                        )
                    }
                }
            }
        }

        // Формат кадру
        Row(
            Modifier.padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Формат:", style = MaterialTheme.typography.labelMedium)
            Ratio.entries.forEach { r ->
                FilterChip(selected = vm.ratio == r, onClick = { vm.ratio = r }, label = { Text(r.label) })
            }
        }

        // Таймлайн
        LazyRow(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            itemsIndexed(clips, key = { _, c -> c.id }) { i, c ->
                val w = (c.durationMs / 1000f * 28f).coerceIn(72f, 360f).dp
                val selected = i == index
                Box(
                    Modifier
                        .width(w).height(72.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(
                            if (selected) 3.dp else 1.dp,
                            if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { player.seekTo(i, 0L) }
                ) {
                    Thumb(c, Modifier.fillMaxSize())
                    Text(
                        "%.1f c".format(c.durationMs / 1000f),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(horizontal = 4.dp)
                    )
                }
            }
            item {
                Box(
                    Modifier.size(72.dp).clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { pickMedia() },
                    contentAlignment = Alignment.Center
                ) { Text("＋", style = MaterialTheme.typography.headlineMedium) }
            }
        }
    }

    // ---------- Діалог експорту ----------
    when (val s = vm.exportState) {
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            title = { Text("Експорт відео…") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { s.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("${s.progress}%")
                }
            },
            confirmButton = { TextButton(onClick = { vm.cancelExport() }) { Text("Скасувати") } }
        )
        is ExportState.Done -> AlertDialog(
            onDismissRequest = { vm.dismissExport() },
            title = { Text("Готово!") },
            text = { Text("Відео збережено в галерею (Movies/VideoEditor).") },
            confirmButton = { TextButton(onClick = { vm.dismissExport() }) { Text("Ок") } }
        )
        is ExportState.Error -> AlertDialog(
            onDismissRequest = { vm.dismissExport() },
            title = { Text("Помилка") },
            text = { Text(s.message) },
            confirmButton = { TextButton(onClick = { vm.dismissExport() }) { Text("Ок") } }
        )
        ExportState.Idle -> {}
    }
}

@Composable
private fun Thumb(clip: Clip, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, clip.uri, clip.startMs) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                if (clip.isImage) {
                    context.contentResolver.openInputStream(clip.uri)?.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 8 })
                    }
                } else {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(context, clip.uri)
                        r.getFrameAtTime(clip.startMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally {
                        r.release()
                    }
                }?.asImageBitmap()
            }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b, null, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(Color.DarkGray))
}
