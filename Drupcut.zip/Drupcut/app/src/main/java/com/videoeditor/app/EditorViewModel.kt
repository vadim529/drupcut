@file:OptIn(UnstableApi::class)

package com.videoeditor.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class EditorViewModel : ViewModel() {

    var clips by mutableStateOf(listOf<Clip>())
        private set
    var ratio by mutableStateOf(Ratio.R169)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    /** Якщо не null — після оновлення плейлиста плеєр перейде на цей кліп. */
    var pendingSeekIndex: Int? = null

    private val nextId = AtomicLong(1)
    private var transformer: Transformer? = null

    // ---------- Імпорт ----------

    fun addClips(app: Context, uris: List<Uri>) {
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.mapNotNull { runCatching { readClip(app, it) }.getOrNull() }
            }
            clips = clips + added
        }
    }

    private fun readClip(app: Context, uri: Uri): Clip {
        val isImage = app.contentResolver.getType(uri)?.startsWith("image/") == true
        val id = nextId.getAndIncrement()
        if (isImage) return Clip(id, uri, true, IMAGE_MAX_MS, 0, IMAGE_DEFAULT_MS)
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(app, uri)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            require(d > 0)
            return Clip(id, uri, false, d, 0, d)
        } finally {
            r.release()
        }
    }

    // ---------- Редагування ----------

    fun trim(id: Long, start: Long, end: Long) {
        clips = clips.map { c ->
            if (c.id != id) c else {
                var s = start.coerceIn(0, c.sourceMs)
                var e = end.coerceIn(0, c.sourceMs)
                if (e - s < MIN_CLIP_MS) {
                    if (s + MIN_CLIP_MS <= c.sourceMs) e = s + MIN_CLIP_MS else s = e - MIN_CLIP_MS
                }
                c.copy(startMs = s, endMs = e)
            }
        }
    }

    fun setImageDuration(id: Long, ms: Long) {
        clips = clips.map { if (it.id == id) it.copy(endMs = ms.coerceIn(500, IMAGE_MAX_MS)) else it }
    }

    /** Розрізати кліп з індексом [index] у позиції [posMs] (відносно початку кліпа на таймлайні). */
    fun split(index: Int, posMs: Long) {
        val c = clips.getOrNull(index) ?: return
        if (c.isImage) return
        if (posMs < MIN_CLIP_MS || c.durationMs - posMs < MIN_CLIP_MS) return
        val cut = c.startMs + posMs
        val a = c.copy(endMs = cut)
        val b = c.copy(id = nextId.getAndIncrement(), startMs = cut)
        clips = clips.toMutableList().apply { removeAt(index); add(index, b); add(index, a) }
        pendingSeekIndex = index + 1
    }

    fun delete(index: Int) {
        if (index !in clips.indices) return
        clips = clips.toMutableList().apply { removeAt(index) }
    }

    fun duplicate(index: Int) {
        val c = clips.getOrNull(index) ?: return
        clips = clips.toMutableList().apply { add(index + 1, c.copy(id = nextId.getAndIncrement())) }
        pendingSeekIndex = index + 1
    }

    fun move(index: Int, dir: Int) {
        val to = index + dir
        if (index !in clips.indices || to !in clips.indices) return
        clips = clips.toMutableList().apply { add(to, removeAt(index)) }
        pendingSeekIndex = to
    }

    // ---------- Експорт ----------

    fun export(app: Context) {
        if (clips.isEmpty() || exportState is ExportState.Running) return
        exportState = ExportState.Running(0)

        val out = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val items = clips.map { c ->
            if (c.isImage) {
                EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                    .setDurationUs(c.durationMs * 1000)
                    .setFrameRate(30)
                    .build()
            } else {
                EditedMediaItem.Builder(c.toMediaItem()).build()
            }
        }
        val sequence = EditedMediaItemSequence.Builder(*items.toTypedArray())
            .experimentalSetForceAudioTrack(true)
            .build()
        val composition = Composition.Builder(listOf(sequence))
            .setEffects(
                Effects(
                    emptyList(),
                    listOf(Presentation.createForWidthAndHeight(ratio.w, ratio.h, Presentation.LAYOUT_SCALE_TO_FIT))
                )
            )
            .build()

        val t = Transformer.Builder(app)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    viewModelScope.launch {
                        val uri = withContext(Dispatchers.IO) { runCatching { saveToGallery(app, out) }.getOrNull() }
                        exportState = if (uri != null) ExportState.Done(uri)
                        else ExportState.Error("Не вдалося зберегти файл у галерею")
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    exportState = ExportState.Error(exportException.message ?: "Помилка експорту")
                }
            })
            .build()
        transformer = t
        t.start(composition, out.absolutePath)

        viewModelScope.launch {
            val holder = ProgressHolder()
            while (exportState is ExportState.Running) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    exportState = ExportState.Running(holder.progress)
                }
                delay(300)
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        exportState = ExportState.Idle
    }

    fun dismissExport() {
        exportState = ExportState.Idle
    }

    private fun saveToGallery(app: Context, file: File): Uri? {
        val resolver = app.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "Montage_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoEditor")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }

    override fun onCleared() {
        transformer?.cancel()
    }
}
